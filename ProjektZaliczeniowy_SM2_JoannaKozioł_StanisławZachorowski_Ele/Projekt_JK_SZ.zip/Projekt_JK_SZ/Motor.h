#ifndef Motor_h
#define Motor_h


void motor_start(void);

void motor_right(void);
void motor_left(void);

#endif
